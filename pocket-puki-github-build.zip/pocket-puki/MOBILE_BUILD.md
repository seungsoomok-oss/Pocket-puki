# Pocket Puki: build APK with only your Android phone

1. Create a **private** repository on github.com named `pocket-puki`.
2. Add all contents of this project at repository root (including `.github/workflows/android-apk.yml`). You can use GitHub web upload, which may be difficult for nested folder uploads on phone; a GitHub-compatible mobile Git client is easier. Do not upload the outer folder as an extra level.
3. Open repository Actions -> Build Pocket Puki APK -> Run workflow.
4. After it succeeds, select the run and download artifact `Pocket-Puki-debug-APK`. Unzip and install `app-debug.apk` on Android.
5. Grant 'Display over other apps' permission; notification permission is optional depending on Android version.

Android may block installs from browser/file manager until you allow 'Install unknown apps' for that app. Use only APK files you built in your own GitHub repository.

This is a **prototype** and its APK build/device behavior has not been verified yet.
