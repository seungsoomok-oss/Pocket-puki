# POCKET PUKI | Android desktop pet (prototype v0.3)

An Android overlay pet, not a website. No HUD, progress meters, menu, or full-screen game. After one-time overlay permission, the launch activity closes and PUKI occasionally appears above other apps, hides at an edge, wanders, suns itself, studies, bathes or naps. Touch PUKI for a brief happy reaction; tilt or shake to summon it. Encounters are stored locally. No internet permission or account required.

## Install
Open the folder in Android Studio, let Gradle sync, connect an Android device, and Run. Alternatively build APK via `./gradlew assembleDebug` after supplying Gradle Wrapper and Android SDK (this source folder does not include the wrapper JAR). An APK has **not** been built or device-tested here. Enable Android's 'Display over other apps' permission on first launch. Android may show a required persistent service notification. Some phone makers disable background services aggressively; adjust battery settings for your own test device.

## Art/behavior disclaimer
The v0.2 generated PUKI sprite artwork is retained. Study book, sunshine, and bath bubbles are runtime graphics, placeholders to be artistically refined. 'Sunny' means a chosen virtual screen position, not actual ambient light or real-world sunlight detection. The pet can overlay only while Android permits overlays, not over all system/security screens. Touch handling is confined to the character's small transparent bounding window (the rectangular touch region may intercept touches within it).

## Share/release
For a public audience, first build/test on actual devices and assess Android/Play foreground service eligibility and overlay permission policy. This is a developer prototype, not a vetted distributable APK. Provide a clear pause/stop control before distribution; force-stop from Android settings is the current prototype's exit.
