package com.pukistudio.pocketpuki

import android.app.*
import android.content.Intent
import android.graphics.PixelFormat
import android.hardware.*
import android.os.*
import android.view.*
import kotlin.math.abs
import kotlin.math.sqrt
import kotlin.random.Random

/** Sparse autonomous desktop-pet behavior across the Android home screen and other apps. */
class PukiService : Service(), SensorEventListener {
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager
    private lateinit var puki: PukiView
    private lateinit var lp: WindowManager.LayoutParams
    private lateinit var sensors: SensorManager
    private val prefs by lazy { getSharedPreferences("puki", MODE_PRIVATE) }
    private var visible = false
    private var lastShake = 0L
    private var lastTilt = 0L
    private var gx = 0f
    private var ax = 0f; private var ay = 0f; private var az = 0f
    private var generation = 0
    private val life = object : Runnable {
        override fun run() {
            if (!visible) appear()
            handler.postDelayed(this, Random.nextLong(50_000L, 125_000L))
        }
    }
    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        val channel = "puki_life"
        nm.createNotificationChannel(NotificationChannel(channel,"푸키의 생활",NotificationManager.IMPORTANCE_LOW))
        val open = PendingIntent.getActivity(this,0,Intent(this,MainActivity::class.java),PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        startForeground(13, Notification.Builder(this,channel).setSmallIcon(android.R.drawable.ic_menu_myplaces)
            .setContentTitle("푸키가 휴대폰 어딘가에 살고 있어요")
            .setContentIntent(open).setOngoing(true).build())
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        puki = PukiView(this)
        lp = WindowManager.LayoutParams(dp(128),dp(154),WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.START; x = -dp(200); y = dp(230) }
        puki.setOnTouchListener { _, event ->
            if (event.action == MotionEvent.ACTION_UP && visible) {
                prefs.edit().putInt("encounters",prefs.getInt("encounters",0)+1).apply()
                puki.activity = PukiView.Activity.HAPPY
                val token = ++generation
                handler.postDelayed({ if(token == generation) disappear() }, 2100L)
            }
            true
        }
        try { wm.addView(puki,lp) } catch (_: Exception) { stopSelf(); return }
        sensors = getSystemService(SENSOR_SERVICE) as SensorManager
        sensors.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)?.let { sensors.registerListener(this,it,SensorManager.SENSOR_DELAY_NORMAL) }
        sensors.getDefaultSensor(Sensor.TYPE_GRAVITY)?.let { sensors.registerListener(this,it,SensorManager.SENSOR_DELAY_NORMAL) }
        handler.postDelayed(life,12_000L)
    }
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY
    private fun appear(forced: Boolean = false, side: Int = if(Random.nextBoolean()) -1 else 1) {
        if (!::puki.isInitialized || (visible && !forced)) return
        val activities = listOf(PukiView.Activity.WALK,PukiView.Activity.PEEK,PukiView.Activity.SUNBATHE,
            PukiView.Activity.STUDY,PukiView.Activity.BATH,PukiView.Activity.NAP)
        val activity = if(forced) PukiView.Activity.SURPRISED else activities.random()
        visible = true
        val token = ++generation
        val screenW = resources.displayMetrics.widthPixels
        val screenH = resources.displayMetrics.heightPixels
        val w = dp(128)
        val edge = activity == PukiView.Activity.PEEK
        lp.x = if(side < 0) { if(edge) -dp(58) else dp(6) } else { if(edge) screenW-dp(68) else screenW-w-dp(6) }
        lp.y = when(activity) {
            PukiView.Activity.SUNBATHE -> dp(76) // A sunny-looking high ledge; not actual ambient-light sensing.
            PukiView.Activity.NAP -> (screenH-dp(255)).coerceAtLeast(dp(120))
            else -> Random.nextInt(dp(145), (screenH-dp(250)).coerceAtLeast(dp(146)))
        }
        puki.facingRight = side < 0
        puki.activity = activity
        update()
        if(activity == PukiView.Activity.WALK) {
            val start = lp.x
            for(step in 1..16) handler.postDelayed({
                if(token == generation) { lp.x = start + if(side < 0) dp(step*4) else -dp(step*4); update() }
            },step*180L)
        }
        val duration = if(forced) 4600L else Random.nextLong(8500L,18000L)
        handler.postDelayed({ if(token == generation) disappear() },duration)
    }
    private fun disappear() {
        visible = false
        ++generation
        lp.x = -dp(220)
        update()
    }
    private fun update() { try { wm.updateViewLayout(puki,lp) } catch (_: Exception) {} }
    override fun onSensorChanged(event: SensorEvent) {
        val now = SystemClock.elapsedRealtime()
        when(event.sensor.type) {
            Sensor.TYPE_GRAVITY -> {
                gx = event.values[0]
                if(abs(gx)>6f && !visible && now-lastTilt>15000L) {
                    lastTilt = now; appear(true,if(gx>0) -1 else 1)
                }
            }
            Sensor.TYPE_ACCELEROMETER -> {
                val k = .82f
                ax = k*ax+(1-k)*event.values[0]; ay=k*ay+(1-k)*event.values[1]; az=k*az+(1-k)*event.values[2]
                val v = sqrt((event.values[0]-ax)*(event.values[0]-ax)+(event.values[1]-ay)*(event.values[1]-ay)+(event.values[2]-az)*(event.values[2]-az))
                if(v>15f && now-lastShake>8000L) { lastShake=now; appear(true) }
            }
        }
    }
    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        if(::sensors.isInitialized) sensors.unregisterListener(this)
        if(::puki.isInitialized) try { wm.removeView(puki) } catch (_: Exception) {}
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
    private fun dp(v:Int) = (v*resources.displayMetrics.density).toInt()
}
