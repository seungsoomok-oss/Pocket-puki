package com.pukistudio.pocketpuki

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.graphics.Color
import android.view.Gravity
import android.widget.TextView
import android.widget.Toast

/** One-time permission onboarding only; the pet itself has no visible UI. */
class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Settings.canDrawOverlays(this)) { startPet(); return }
        val message = TextView(this).apply {
            text = "푸키가 화면 구석에 숨어 살려면\n'다른 앱 위에 표시' 권한을 허용해줘.\n\n여기를 눌러 허용하기"
            textSize = 20f; gravity = Gravity.CENTER
            setTextColor(Color.rgb(43,55,32)); setBackgroundColor(Color.rgb(248,249,239))
            setOnClickListener { startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,Uri.parse("package:$packageName"))) }
        }
        setContentView(message)
    }
    override fun onResume() { super.onResume(); if(Settings.canDrawOverlays(this)) startPet() }
    private fun startPet() {
        try { startForegroundService(Intent(this,PukiService::class.java)); finish() }
        catch(e:Exception) { Toast.makeText(this,"푸키 시작 오류: ${e.message}",Toast.LENGTH_LONG).show() }
    }
}
