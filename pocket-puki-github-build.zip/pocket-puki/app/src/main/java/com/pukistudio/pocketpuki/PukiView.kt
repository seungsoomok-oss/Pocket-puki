package com.pukistudio.pocketpuki

import android.content.Context
import android.graphics.*
import android.view.View
import kotlin.math.sin

/** Transparent animated character. No panels, buttons or HUD. */
class PukiView(context: Context) : View(context) {
    enum class Activity { WALK, PEEK, SUNBATHE, STUDY, BATH, NAP, SURPRISED, HAPPY }
    private val sprites = mapOf(
        Activity.WALK to R.drawable.puki_idle,
        Activity.PEEK to R.drawable.puki_curious,
        Activity.SUNBATHE to R.drawable.puki_happy,
        Activity.STUDY to R.drawable.puki_idle,
        Activity.BATH to R.drawable.puki_happy,
        Activity.NAP to R.drawable.puki_sleepy,
        Activity.SURPRISED to R.drawable.puki_startled,
        Activity.HAPPY to R.drawable.puki_happy
    ).mapValues { BitmapFactory.decodeResource(resources, it.value) }
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    var activity = Activity.PEEK
        set(value) { field = value; invalidate() }
    var facingRight = true
        set(value) { field = value; invalidate() }
    private val born = android.os.SystemClock.uptimeMillis()
    init { setBackgroundColor(Color.TRANSPARENT) }
    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val time = (android.os.SystemClock.uptimeMillis() - born) / 1000f
        val d = resources.displayMetrics.density
        val bob = if (activity == Activity.NAP || activity == Activity.STUDY) 0f else sin(time * 3.2f) * 3f * d
        val bitmap = sprites[activity] ?: return
        canvas.save()
        if (!facingRight) canvas.scale(-1f, 1f, width / 2f, height / 2f)
        val maxW = width * .85f
        val maxH = height * .70f
        val scale = minOf(maxW / bitmap.width, maxH / bitmap.height)
        val w = bitmap.width * scale
        val h = bitmap.height * scale
        val left = (width-w)/2f
        val top = (height-h)/2f + bob
        canvas.drawBitmap(bitmap, null, RectF(left, top, left+w, top+h), paint)
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 2.3f * d
        paint.color = Color.rgb(44, 49, 24)
        paint.strokeCap = Paint.Cap.ROUND
        when (activity) {
            Activity.STUDY -> {
                val x = width * .53f; val y = height * .87f
                paint.style = Paint.Style.FILL
                paint.color = Color.rgb(247, 242, 219)
                canvas.drawRoundRect(RectF(x-24*d,y-17*d,x+25*d,y+9*d),3*d,3*d,paint)
                paint.style = Paint.Style.STROKE; paint.color = Color.rgb(44,49,24)
                canvas.drawRoundRect(RectF(x-24*d,y-17*d,x+25*d,y+9*d),3*d,3*d,paint)
                canvas.drawLine(x,y-17*d,x,y+9*d,paint)
                canvas.drawLine(x-17*d,y-9*d,x-6*d,y-9*d,paint)
            }
            Activity.BATH -> {
                paint.color = Color.rgb(83, 169, 199)
                paint.style = Paint.Style.STROKE
                val y = height * .82f
                canvas.drawArc(RectF(width*.18f,y-10*d,width*.82f,y+25*d), 0f, 180f,false,paint)
                paint.style = Paint.Style.FILL
                for(i in 0..3) {
                    val x = width * (.26f + i*.15f)
                    canvas.drawCircle(x, y - (14 + (i%2)*9)*d + sin(time*2+i)*3*d, (3+i%2)*d, paint)
                }
            }
            Activity.SUNBATHE -> {
                paint.color = Color.rgb(242,190,72); paint.style = Paint.Style.FILL
                canvas.drawCircle(width*.84f, height*.19f, 8*d, paint)
                paint.style = Paint.Style.STROKE
                for(i in 0..7) {
                    val a = i*Math.PI/4
                    val cx = width*.84f; val cy = height*.19f
                    canvas.drawLine(cx+kotlin.math.cos(a).toFloat()*12*d,cy+kotlin.math.sin(a).toFloat()*12*d,cx+kotlin.math.cos(a).toFloat()*16*d,cy+kotlin.math.sin(a).toFloat()*16*d,paint)
                }
            }
            Activity.NAP -> {
                paint.color = Color.rgb(50,60,32); paint.style = Paint.Style.FILL; paint.textSize = 15*d
                canvas.drawText("z",width*.76f,height*.19f + sin(time)*3*d,paint)
            }
            else -> Unit
        }
        paint.style = Paint.Style.FILL; paint.color = Color.WHITE
        canvas.restore()
        postInvalidateDelayed(80L)
    }
}
